# Setup Guide: The Autonomous Business Loop
**Time required: 20 minutes**
**What you need: Claude.ai Pro or ChatGPT Plus**

---

This guide gets your first loop running. We're using the SEO loop as the example because it's the easiest to verify — you'll see real output within minutes.

Don't skip steps. Each one takes 2 minutes or less.

---

## Part 1: What You Need Before You Start
**Time: 5 minutes**

### Required
- An active Claude.ai Pro subscription **or** ChatGPT Plus subscription ($20/month)
- A Google account (for Google Docs — free)
- Your business website URL
- 3–5 keywords your customers actually search for

That's it. No installs. No API keys. No code.

### Nice to Have (Not Required)
- A Notion account (free tier works)
- A Zapier account (free tier works for one zap)

### Check Your Subscription
Open Claude.ai or ChatGPT. Look for the model selector at the top.

[Screenshot: Claude.ai showing "Claude 3.5 Sonnet" selected in the top dropdown — or ChatGPT showing "GPT-4o" in the model selector]

If you see a model option, you're on the paid plan. Good. Keep going.

If you only see one option with no selector, you're on a free plan. Upgrade first. The loops won't run reliably on free tiers.

---

## Part 2: Installing Your First Loop (The SEO Loop)
**Time: 10 minutes**

### Step 1: Open Your Loop File

In the files you downloaded, find the folder called **loop-files**. Open the file named **seo-loop.md**.

[Screenshot: File explorer showing the loop-files folder with seo-loop.md highlighted]

You'll see a block of text that starts with something like:

```
SYSTEM CONTEXT:
You are an SEO content assistant for [BUSINESS NAME]...
```

This is your loop file. It's a pre-written prompt. Your job is to customize it, then paste it in.

### Step 2: Fill In Your Business Details

You'll see placeholders in [BRACKETS]. Replace every single one.

Here's what to look for:

| Placeholder | Replace With |
|---|---|
| [BUSINESS NAME] | Your actual business name |
| [WEBSITE URL] | Your website (e.g., scottshop.com) |
| [PRIMARY KEYWORD] | Your #1 search term |
| [SECONDARY KEYWORDS] | 3–5 related keywords, comma separated |
| [TARGET CUSTOMER] | One sentence: who buys from you |
| [CONTENT GOAL] | Blog post / product page / FAQ — pick one |

**Don't overthink this.** Write rough, direct answers. The loop handles the polishing.

[Screenshot: seo-loop.md open in a text editor with [BUSINESS NAME] highlighted and replaced with example text]

### Step 3: Open a New Chat

Go to Claude.ai or ChatGPT. Start a **new conversation**. Don't use an old thread.

[Screenshot: Claude.ai with the "New chat" button circled in the sidebar]

### Step 4: Paste the Loop

Copy your entire filled-in loop file. Paste it into the chat. Hit Enter.

The AI will respond. It should produce a structured SEO content brief — headlines, keyword targets, an article outline, and suggested meta description.

[Screenshot: Example of the SEO loop output inside Claude.ai — showing structured content sections]

**If it just says "Got it" or asks a clarifying question:** That's fine. Paste this follow-up:

> "Please run the full loop now and give me complete output."

It will then produce the full brief.

### Step 5: Save the Output

Copy the output. Paste it into a Google Doc. Title it:

**SEO Loop — [Date] — [Keyword]**

Example: *SEO Loop — June 13 — AI tools for solopreneurs*

This is your output archive. You'll build one of these every time the loop runs.

[Screenshot: Google Doc with the loop output pasted and title bar showing the naming convention]

### Step 6: Verify the Output Quality

Before you schedule anything, make sure the output is actually useful. Check for:

- [ ] The article headline mentions your keyword
- [ ] The outline has at least 5 sections
- [ ] The meta description is under 160 characters
- [ ] The tone sounds like your business, not a generic AI

If any of these fail, go back to Step 2 and tighten your [TARGET CUSTOMER] and [PRIMARY KEYWORD] fields. One specific edit usually fixes it.

---

## Part 3: Setting Your First Schedule
**Time: 5 minutes**

Right now, you ran the loop manually. That's fine for testing. But the goal is to run it without you.

Here's the simplest way to schedule it.

### Option A: Zapier (Recommended for Beginners)

1. Go to zapier.com and create a free account
2. Click **Create Zap**
3. Set the Trigger to: **Schedule by Zapier** → Every Week → Monday → 7:00 AM

[Screenshot: Zapier trigger setup showing "Schedule by Zapier" selected with "Every Week" dropdown visible]

4. Set the Action to: **Gmail** → Send Email (to yourself)
   - Subject: `Run SEO Loop Today`
   - Body: Paste your loop prompt text

5. Turn the Zap on

Every Monday at 7 AM, you'll get an email with the loop prompt. Open it, paste it into Claude or ChatGPT, save the output. Takes 3 minutes.

That's a scheduled loop. Simple version, but it works.

### Option B: Google Calendar Reminder

If you don't want to use Zapier:

1. Open Google Calendar
2. Create a recurring event: **Monday 7 AM — Run SEO Loop**
3. Set it to repeat every week
4. In the event description, paste your loop prompt

When the reminder fires, open Claude or ChatGPT, paste the prompt, save the output.

Less automated than Zapier. Still beats starting from scratch every session.

### Option C: Full Automation with Make (Advanced)

If you're comfortable spending 30 minutes on setup, you can connect Make (formerly Integromat) to send your loop prompt directly to the OpenAI API and save the output to Notion automatically.

This is covered in **Chapter 4** of the main guide. Start with Option A first. Get the loop working. Then upgrade.

---

## Part 4: Verifying It Worked

Run the loop one more time manually. Open a new chat. Paste the prompt. Check the output against this list:

**Output Checklist**
- [ ] Output appeared in under 60 seconds
- [ ] Output is at least 400 words
- [ ] Output references your keyword at least 3 times
- [ ] Output is saved to your Google Doc archive

**Schedule Checklist**
- [ ] Zapier Zap is turned ON (or calendar reminder is set)
- [ ] You received a test trigger email (Zapier lets you test this before going live)

[Screenshot: Zapier dashboard showing the Zap as "ON" with a green toggle]

If both checklists pass, you're done.

Your first loop is live.

---

## What's Next

You've installed one loop. There are three more in the **loop-files** folder:

- **content-repurpose-loop.md** — turns one piece of content into 5 formats
- **client-follow-up-loop.md** — writes follow-up sequences for leads
- **weekly-review-loop.md** — summarizes your week and flags priorities

Install them the same way. Customize the brackets. Pick a schedule. Done.

If something didn't work, check the **QUICK-START.md** troubleshooting section first. Most issues come down to two things: a missing bracket replacement, or pasting into an old chat thread instead of a new one.

---

*Setup Guide — The Autonomous Business Loop by Scott Hunt*
*Version 1.0*
