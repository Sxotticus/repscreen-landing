# Sales Page Outline: The Autonomous Business Loop

*One-page landing page structure. Scott drops in final copy and goes live.*

---

## SECTION 1: HERO

**Headline:**
# Stop Babysitting Your AI. Build Loops That Run Without You.

**Subheadline:**
The no-code system for solopreneurs who want AI automation for small business — without hiring a developer or learning to code.

**CTA Button:**
`Get Instant Access — $49`

**Under the button:**
One payment. Lifetime access. No subscriptions.

---

## SECTION 2: THE PROBLEM

### You're Using AI the Hard Way

**Pain Point 1: Starting from scratch every session**
Every time you open ChatGPT or Claude, you start over. No memory. No context. You rebuild the same prompt you wrote last week. That's not automation — that's manual labor with extra steps.

**Pain Point 2: Great output, no system**
You've had sessions where the AI produced something genuinely useful. But you can't replicate it. You don't remember what prompt you used. You can't run it again without sitting there doing it yourself. The output exists. The system doesn't.

**Pain Point 3: You know you should automate. You don't know how.**
Every article about AI automation says "use Zapier" or "connect your API." You open Zapier. You see 400 options. You close the tab. The gap between "I want automation" and "I have automation" stays exactly as wide as it was.

---

## SECTION 3: THE SOLUTION

### The Loop Changes Everything

A loop is a pre-built prompt with a schedule attached.

You set it up once. It runs on a timer. It produces consistent output. You use the output. You don't rewrite the prompt. You don't open a blank chat. You don't start over.

**The Autonomous Business Loop** is the complete system for building, scheduling, and running AI loops in your business — with no code, no developer, and no technical background required.

If you can copy and paste, you can run a loop.

---

## SECTION 4: WHAT'S INSIDE

### Everything You Need to Build Your First Loop This Week

*(Feature → Benefit format)*

---

**5 Chapters + Bonus (~13,500 words)**
→ You understand exactly how the system works, not just how to copy it. When something goes sideways, you can fix it yourself.

---

**4 Ready-to-Run Loop Files**
→ You don't build from scratch. Open the file, fill in your business details, paste it in, set a schedule. Your first loop is live in 20 minutes.

*Included loops:*
- SEO Content Loop — builds a full content brief every week on autopilot
- Content Repurpose Loop — turns one piece of content into 5 formats automatically
- Client Follow-Up Loop — writes follow-up sequences for leads without you
- Weekly Business Review Loop — summarizes your week and surfaces what matters

---

**20-Minute Setup Guide**
→ You don't get lost. Every step is written for a non-technical person. Screenshots included. Clear instructions, one at a time.

---

**5-Minute Quick-Start Cheat Sheet**
→ You get a working loop running today, even before you read the full guide.

---

**30+ Prompt Library**
→ You have tested, ready-to-use prompts for every loop and use case. No blank page, ever.

---

## SECTION 5: PRICING

### One Price. Everything Included.

---

**The Autonomous Business Loop — Full Guide**
**$49**

- All 5 chapters + bonus
- All 4 loop files
- Setup guide
- Quick-start cheat sheet
- 30+ prompt library
- Lifetime updates

`Get Instant Access — $49`

*One payment. No subscription. Instant download.*

---

*(Optional — add when ready)*
**Bundle + Community: $97**
Everything above, plus access to the private community, monthly live Q&As, and member-only loop templates.

---

## SECTION 6: FAQ

**Do I need to know how to code?**
No. The loops are pre-written. You fill in your business name and a few details, then paste them into Claude or ChatGPT. That's it.

**What AI tool do I need?**
ChatGPT Plus ($20/month) or Claude.ai Pro ($20/month). Either works. You need the paid plan — free tiers don't run the loops reliably.

**How fast can I have my first loop running?**
The Quick-Start gets you running in 5 minutes. The full setup takes 20. You could have your first loop live before lunch today.

**What if I try it and it doesn't work for my business?**
The guide has a troubleshooting section for the most common issues. Most problems take one small edit to fix. If you're genuinely stuck, the problem is usually one vague placeholder — the fix takes 30 seconds once you know where to look.

**Is this a subscription?**
No. One payment. Lifetime access. Future updates are free.

---

## SECTION 7: CTA

### Your AI should work while you sleep. Set it up today.

Right now, every AI session you run costs you time. You open a blank chat. You write the same prompt again. You get output you can't replicate. You close the tab and start over next week.

A loop fixes that. One 20-minute setup. Then it runs without you.

**Get The Autonomous Business Loop for $49.**

`Get Instant Access Now`

*One payment. Instant download. Lifetime updates.*

---

*Sales Page Outline — The Autonomous Business Loop by Scott Hunt*
*Version 1.0 — Fill in final copy and publish*
