# Quick-Start: Your First Loop in 5 Minutes

**One page. Three steps. No fluff.**

---

## Before You Open Anything

You need:
- Claude.ai Pro **or** ChatGPT Plus (paid plan, $20/month)
- Your downloaded loop files (look for the **loop-files** folder)
- 5 minutes

---

## Step 1: Grab the Loop File (1 min)

Open the **loop-files** folder from your download.

Open **seo-loop.md** in any text editor (Notes, Notepad, TextEdit — anything works).

→ **[Loop file location: loop-files/seo-loop.md]**

---

## Step 2: Fill It In and Paste It (3 min)

Find every word in [BRACKETS]. Replace them with your real info.

**Six things to replace:**

1. `[BUSINESS NAME]` → Your business name
2. `[WEBSITE URL]` → Your website
3. `[PRIMARY KEYWORD]` → Your #1 search term
4. `[SECONDARY KEYWORDS]` → 3–5 related terms
5. `[TARGET CUSTOMER]` → One sentence describing who buys from you
6. `[CONTENT GOAL]` → Blog post, product page, or FAQ

Open Claude.ai or ChatGPT. **Start a new chat.** Paste the whole thing. Hit Enter.

Wait 30–60 seconds. You'll get a full SEO content brief.

---

## Step 3: Save the Output and Set Your Schedule (1 min)

Copy the output. Paste it into a Google Doc. Title it:
**SEO Loop — [Today's Date] — [Your Keyword]**

Then set a recurring reminder (Google Calendar or Zapier) to run this loop every Monday morning.

That's it. **Your first loop is live.**

---

## If This Goes Wrong

**Problem 1: The AI asks me a question instead of running the loop.**

Fix: Paste this into the same chat — *"Please run the full loop now and give me complete output."* — then hit Enter. It'll run.

---

**Problem 2: The output looks generic and doesn't sound like my business.**

Fix: You left a bracket too vague. Go back to `[TARGET CUSTOMER]` and make it more specific. Instead of "small business owners," write "freelance copywriters who charge $3K+ per project." Specific input = specific output.

---

**Problem 3: My Zapier zap isn't triggering.**

Fix: Check two things. First, make sure the Zap is toggled **ON** (green) in your Zapier dashboard. Second, your free Zapier account only allows the zap to run every 15 minutes minimum — for weekly loops this is fine, but make sure the trigger is set to "Every Week" not "Every 15 Minutes." Test the zap manually from the Zapier dashboard before your first scheduled run.

---

## Your Four Loop Files

| File | What It Does | Suggested Schedule |
|---|---|---|
| seo-loop.md | Builds SEO content briefs | Every Monday |
| content-repurpose-loop.md | Turns 1 piece into 5 formats | After every new post |
| client-follow-up-loop.md | Writes follow-up sequences | Every Tuesday |
| weekly-review-loop.md | Reviews your week, flags priorities | Every Friday at 4 PM |

Start with one. Get it working. Then add the next.

---

## Still Stuck?

Check the full **SETUP-GUIDE.md** — it walks through every step with screenshots.

For anything else: the 30+ prompt library in **prompt-library.md** has variations for every loop.

---

*Quick-Start — The Autonomous Business Loop by Scott Hunt*
