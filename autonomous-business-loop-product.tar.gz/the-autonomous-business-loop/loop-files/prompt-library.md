# Prompt Library — 30+ Ready-to-Use Triggering Prompts
### The Autonomous Business Loop by Scott Hunt

---

> **HOW TO USE THIS LIBRARY**
> Every prompt below is ready to copy and paste. Some have `[BRACKETS]` — replace those with your own info before pasting. Others work exactly as written.
>
> These are "triggering prompts" — you paste them into Claude (or your Claude Project) and they kick off a complete workflow. You don't need to know anything about AI to use them. Just pick the one that matches what you need, paste it, fill in the brackets, and hit send.

---

## SEO

**Full Page SEO Audit** — Scores your page on 10 factors and rewrites it for better rankings
```
Act as an expert SEO auditor. I'm going to paste the full text of a web page. My target keyword is [PASTE YOUR KEYWORD HERE].

Please score this page on a scale of 0–100 using these 10 categories:
1. Keyword in page title (15 pts)
2. Keyword density in body text (15 pts)
3. Keyword in first paragraph (10 pts)
4. Keyword in subheadings (10 pts)
5. Heading hierarchy (H1, H2, H3 used correctly) (5 pts)
6. Meta description quality (10 pts)
7. URL slug (5 pts)
8. Internal links (15 pts)
9. Readability (10 pts)
10. Content length (5 pts)

After scoring, rewrite the page to improve any score below 8/10. Show me the before score, the rewritten content, and the after score. Keep my tone and main message the same — just optimize it for SEO.

Here is my page content:
[PASTE YOUR CONTENT HERE]
```

---

**Title Tag Generator** — Writes 5 SEO-optimized title tag options for any page
```
Write 5 title tags for a web page about [DESCRIBE YOUR PAGE TOPIC]. My target keyword is [YOUR KEYWORD].

Rules for each title:
- Include the exact keyword, ideally near the beginning
- Keep it under 60 characters
- Make it interesting enough that someone would want to click it
- Do NOT use clickbait or all caps

After the 5 options, tell me which one you'd recommend and why.
```

---

**Meta Description Writer** — Creates click-worthy meta descriptions that include your keyword
```
Write 5 meta descriptions for a page targeting the keyword [YOUR KEYWORD].

Rules:
- Each must be between 120–155 characters (show the character count after each one)
- Include the exact keyword naturally
- Make it feel like a human wrote it — not a robot
- End with a subtle call to action when possible (e.g., "Learn how," "Find out," "See the full list")

The page is about: [BRIEFLY DESCRIBE THE PAGE]
```

---

**Blog Post SEO Outline** — Builds a keyword-optimized outline before you write anything
```
Create a detailed SEO blog post outline for the keyword "[YOUR TARGET KEYWORD]."

The outline should include:
- 1 H1 title (with the keyword near the beginning)
- 5–8 H2 subheadings (use keyword variations, not the exact keyword every time)
- 2–3 H3 sub-points under each H2
- A suggested word count for each section
- A note on search intent: what is the reader trying to DO or FIND when they search this keyword?
- 3 internal link opportunities (sections where I should link to other pages on my site)

My website is about: [YOUR NICHE]
```

---

**Internal Link Finder** — Identifies where to add internal links to boost SEO
```
I'm going to paste two pieces of content from my website. Tell me:
1. Where in Content A I should add a link to Content B (give the exact anchor text and the sentence it fits in)
2. Where in Content B I should add a link to Content A
3. Any other linking opportunities you spot

Content A — [PAGE TITLE]:
[PASTE CONTENT A]

Content B — [PAGE TITLE]:
[PASTE CONTENT B]
```

---

**Keyword Cluster Builder** — Groups related keywords so you can plan content strategically
```
I sell [YOUR PRODUCT OR SERVICE] and my main keyword is "[YOUR MAIN KEYWORD]."

Build me a keyword cluster — a group of related keywords organized by topic. Format it like this:
- PILLAR KEYWORD: [main keyword]
  - Supporting keyword 1
  - Supporting keyword 2
  - Supporting keyword 3 (etc.)

Give me 5 different topic clusters, each with 1 pillar keyword and 4–6 supporting keywords. These should be terms real people actually search, not made-up phrases.
```

---

## Content Creation

**Blog Post Draft in My Voice** — Writes a full blog post that sounds like you
```
Write a [WORD COUNT — e.g., "900-word"] blog post about "[TOPIC]."

My writing style is [DESCRIBE YOUR VOICE — e.g., "casual and funny, like I'm talking to a friend" or "direct and professional, no fluff"]. Here's an example of my writing to match:

[PASTE A PARAGRAPH OR TWO OF YOUR PREVIOUS WRITING]

Requirements:
- Start with a hook — a surprising stat, relatable problem, or bold statement
- Use short paragraphs (3–4 sentences max)
- Include subheadings every 200–300 words
- End with a clear call to action: [WHAT YOU WANT READERS TO DO]
- Target keyword (weave it in naturally, don't force it): [YOUR KEYWORD]
```

---

**Headline Formula Pack** — Generates 10 headline options using proven formats
```
Generate 10 headline options for an article about [YOUR TOPIC].

Use these proven formats — write at least one of each:
1. Number list: "X Ways to..."
2. How-to: "How to [Achieve Result] Without [Common Obstacle]"
3. Question: "Are You [Common Mistake]?"
4. Myth-busting: "Why [Common Belief] Is Wrong"
5. Urgency: "[Achieve Result] Before [Deadline or Trigger]"
6. Beginner-friendly: "The Complete Beginner's Guide to..."
7. Comparison: "[Option A] vs. [Option B]: Which Is Better?"
8. Personal story: "I [Did Unusual Thing] for [Time Period]. Here's What Happened."
9. Curiosity gap: "The [Unexpected Thing] Nobody Tells You About [Topic]"
10. Direct benefit: "[Do X] and [Get Y Result] in [Timeframe]"

My target reader is: [DESCRIBE YOUR AUDIENCE]
```

---

**Weekly Content Calendar Builder** — Plans 4 weeks of content in one go
```
Build me a 4-week content calendar for my [TYPE OF BUSINESS] in the [YOUR NICHE] space.

Each week should include:
- 1 blog post topic (with suggested keyword)
- 3 social media post ideas
- 1 email newsletter angle

My audience is [DESCRIBE YOUR AUDIENCE]. They care most about [TOP 2–3 PAIN POINTS OR DESIRES].

Format it as a clean weekly plan I can follow. Keep topics varied — don't repeat the same angle twice.
```

---

**Content Repurposing Expander** — Turns one piece of content into 6 different formats
```
I have an existing [blog post / newsletter / YouTube video transcript] that I want to repurpose. Turn it into:

1. An Instagram carousel post (8 slides, each slide = one key point, plus a first slide hook and last slide CTA)
2. A Twitter/X thread (8–10 tweets)
3. A LinkedIn post (200–250 words, professional but warm)
4. A short-form video script (60–90 seconds, designed for TikTok or Instagram Reels)
5. An email newsletter (subject line + 250-word email version)
6. A Pinterest description (keyword-rich, 100–150 words)

Here is the original content:
[PASTE YOUR CONTENT]
```

---

## Market Research

**Audience Pain Point Excavator** — Uncovers the real frustrations your customers have
```
I sell [YOUR PRODUCT OR SERVICE] to [YOUR TARGET AUDIENCE].

Give me a deep-dive list of their pain points organized into 3 levels:

SURFACE PAINS (what they complain about openly):
[list 5]

DEEPER FRUSTRATIONS (what's underneath the surface complaint):
[list 5]

HIDDEN FEARS (what they'd never say out loud but secretly worry about):
[list 5]

For each pain point, write one sentence showing how my [product/service] could address it. Keep it honest — don't stretch.
```

---

**Market Gap Scanner** — Finds opportunities your competitors are missing
```
I'm in the [YOUR NICHE] market selling [YOUR PRODUCT OR SERVICE].

Analyze this market and tell me:
1. What are the top 3–5 things people in this market complain most about when reviewing existing products? (Think: what do 1-star and 2-star Amazon/Etsy reviews say?)
2. What niches within this market are underserved? (Who is nobody targeting well?)
3. What price points are crowded vs. open? (Is there a gap at the premium or budget end?)
4. What content topics does this market keep asking about that nobody is answering well?
5. What product formats (digital vs. physical, one-time vs. subscription, etc.) are missing?

Give me specific, actionable observations — not generic advice.
```

---

**Customer Avatar Builder** — Creates a detailed profile of your ideal buyer
```
Build a detailed customer avatar for a buyer of [YOUR PRODUCT OR SERVICE].

Include:
- Name (made up, but realistic)
- Age, occupation, income range
- Where they spend time online
- Top 3 goals related to [YOUR NICHE]
- Top 3 fears or frustrations related to [YOUR NICHE]
- What they've already tried that didn't work
- What they type into Google when looking for a solution
- What would make them trust a seller enough to buy
- What would make them immediately leave a product page

Write this as a narrative profile (like a short story about a real person), then follow it with a bullet-point summary.
```

---

**Product Idea Validator** — Tests whether a new product idea is worth pursuing
```
I'm thinking about creating a new [product type — e.g., "digital course," "Etsy printable," "SaaS tool"] for [TARGET AUDIENCE]. The concept is: [DESCRIBE YOUR IDEA IN 2–3 SENTENCES].

Help me validate this idea by answering:
1. Who is already doing something like this? (name similar products/competitors)
2. What's missing or weak in existing similar products?
3. What would make someone pay for THIS over what's already out there?
4. What's a realistic price point based on comparable products?
5. What's the fastest way to test demand before I build the whole thing?
6. What are the top 3 reasons this idea might fail?
7. Overall verdict: Strong opportunity / Crowded but winnable / Avoid — and why
```

---

## Competitor Monitoring

**Competitor Product Page Breakdown** — Analyzes a competitor's page and finds your advantages
```
I'm going to paste the full text of a competitor's product page. Analyze it and tell me:

1. What are they doing really well? (What would make a buyer trust them and click "buy"?)
2. What are their weaknesses? (What questions does this page leave unanswered? What objections aren't handled?)
3. What promises are they making? (List every benefit claim they make)
4. What social proof do they use? (reviews, testimonials, press mentions, numbers)
5. What is their pricing strategy? (premium / budget / value)
6. What would make someone choose my product over theirs? (Give me 3 positioning angles I could use)

Competitor page content:
[PASTE THE PAGE TEXT HERE]

My product is: [BRIEF DESCRIPTION OF YOUR PRODUCT]
```

---

**Competitor Pricing Intelligence Report** — Tracks and analyzes what competitors charge
```
I'm going to give you the current pricing for 3–5 competitors in my market. Analyze this pricing data and tell me:

1. What is the price range in this market? (Low / Mid / High thresholds)
2. What price point has the most competition? (Where is it crowded?)
3. Where is there a pricing gap? (What price point is underserved?)
4. What pricing model is most common? (one-time / subscription / tiered)
5. Where should I price my product to maximize perceived value AND conversions?
6. What should I include in my offer to justify my price?

Competitor pricing:
Competitor 1 — [NAME]: [PRICE / MODEL]
Competitor 2 — [NAME]: [PRICE / MODEL]
Competitor 3 — [NAME]: [PRICE / MODEL]
Competitor 4 — [NAME]: [PRICE / MODEL — optional]

My product: [BRIEF DESCRIPTION]
My current price (or planned price): [PRICE]
```

---

**Competitor Content Gap Analysis** — Finds what topics your competitors aren't covering
```
I want to find content topics that my competitors haven't addressed (or have addressed poorly).

My niche: [YOUR NICHE]
My competitors' websites: [LIST 2–3 COMPETITOR WEBSITE URLS OR NAMES]

Based on typical content in this niche, tell me:
1. What questions is my target audience asking that competitors are NOT answering well?
2. What content formats are missing? (video, comparison posts, beginner guides, case studies, etc.)
3. What sub-topics within [YOUR NICHE] are underrepresented in content?
4. Give me 5 specific blog post or video titles I could create that would fill real gaps

For each content gap, estimate: High opportunity / Medium opportunity / Low opportunity
```

---

## Email / Newsletter

**Welcome Email Sequence Writer** — Writes a 5-email onboarding sequence for new subscribers
```
Write a 5-email welcome sequence for new subscribers to my email list. I sell [YOUR PRODUCT OR SERVICE] to [YOUR AUDIENCE].

The goal of the sequence is to build trust, deliver value, and eventually invite them to [YOUR MAIN OFFER / CALL TO ACTION].

For each email, write:
- Subject line
- Preview text (under 60 characters)
- Full email body (200–350 words, conversational, not salesy)
- Sending timing (e.g., "Send immediately," "Send on Day 3")

Email 1: Welcome + what to expect
Email 2: Your best free resource or tip
Email 3: A story that shows you understand their problem
Email 4: Social proof (testimonials, results, case study)
Email 5: Soft pitch for [YOUR PRODUCT OR OFFER]

My tone: [DESCRIBE — e.g., "warm and encouraging" or "blunt and no-nonsense"]
```

---

**Weekly Newsletter Draft** — Writes a complete newsletter around a single topic
```
Write a weekly email newsletter for my audience of [YOUR AUDIENCE]. Topic this week: [YOUR TOPIC].

Format:
- Subject line (5–7 words, creates curiosity or promises value)
- Preview text (40–60 characters)
- Opening hook (1–2 sentences — grab attention immediately)
- Main section (3–4 short paragraphs — the meat of the newsletter)
- Quick tip or resource (one actionable thing they can use today)
- Call to action (one clear ask — read the post, buy the product, reply to this email, etc.)
- Signoff (warm, personal, 1–2 sentences)

Keep it under 500 words total. My newsletters are [DESCRIBE TONE — e.g., "like a letter from a friend, not a corporate email blast"].
```

---

**Re-Engagement Email** — Wins back subscribers who haven't opened in 60+ days
```
Write a re-engagement email for subscribers who haven't opened my emails in 60+ days.

The email should:
- Acknowledge that we've been quiet (or that they've been busy — no blame)
- Remind them what value they signed up for
- Give them something useful right in the email (a quick tip, a free resource, or a bold insight)
- Ask them to stay — but make it easy to unsubscribe if they want to

My business: [BRIEF DESCRIPTION]
My audience: [YOUR AUDIENCE]
Tone: [DESCRIBE — e.g., "honest and a little self-aware" or "energetic and direct"]

Do NOT be dramatic or guilt-tripping. Keep it under 200 words.
```

---

## App Store

**App Store Description Optimizer** — Rewrites your app description to drive more downloads
```
Rewrite my App Store (or Google Play) app description to increase downloads. My current description is below.

Optimize it for:
1. The first 3 lines (most important — this is what shows before "Read More")
2. Clear benefit statements (what does the app DO for the user?)
3. Keyword-rich language (naturally woven in, not stuffed)
4. Social proof hooks (mention ratings, users, or awards if I have them)
5. A strong closing call to action

My app: [APP NAME]
Category: [APP CATEGORY]
Target user: [WHO IS THIS APP FOR]
Top 3 keywords I want to rank for: [LIST THEM]
Current description:
[PASTE YOUR CURRENT DESCRIPTION]
```

---

**App Review Response Writer** — Drafts professional replies to App Store reviews
```
Write professional, human-sounding replies to these App Store reviews. For each reply:
- Match the tone to the review (warm for compliments, calm and solution-focused for complaints)
- Keep replies under 150 words
- Never be defensive or blame the user
- Always end with an invitation to contact support if there's an issue

Reviews to reply to:

Review 1 (⭐⭐⭐⭐⭐): "[PASTE 5-STAR REVIEW TEXT]"

Review 2 (⭐⭐): "[PASTE NEGATIVE REVIEW TEXT]"

Review 3 (⭐⭐⭐): "[PASTE 3-STAR REVIEW TEXT]"

My app is: [APP NAME — BRIEF DESCRIPTION]
My support email is: [YOUR EMAIL] (include this in any reply where customer support would help)
```

---

## Social Media

**30-Day Instagram Content Plan** — Plans a full month of posts around your niche
```
Build me a 30-day Instagram content plan for a [TYPE OF ACCOUNT — e.g., "business coach," "Etsy seller," "fitness brand"].

My niche: [YOUR NICHE]
My audience: [WHO FOLLOWS ME]
My goal for Instagram: [GROW FOLLOWING / DRIVE SALES / BUILD COMMUNITY / etc.]

For each of the 30 days, give me:
- Content type (Reel, Carousel, Static image, Story, etc.)
- Topic/angle
- First line of the caption (the hook — what appears before "more")
- 3–5 hashtags specific to that post

Organize it by week. Make the content mix feel natural — not like every post is selling something.
```

---

**Viral Hook Generator** — Writes opening lines designed to stop the scroll
```
Write 10 viral hook lines for social media content about [YOUR TOPIC].

A "hook" is the first line someone sees — it must make them stop scrolling and want to read more.

Use these hook types (write at least 1 of each):
- Counterintuitive: "Most [audience] are doing [thing] wrong."
- Curiosity gap: "There's a reason [common thing] doesn't work for most people."
- Bold claim: "I made $[X] without doing [common expected thing]."
- Story opener: "In [year], I [did something]. I had no idea it would [lead to result]."
- Question: "Would you rather [Option A] or [Option B]?"

My audience: [YOUR AUDIENCE]
My topic/niche: [YOUR TOPIC]
My tone: [e.g., "confident and direct" / "warm and relatable" / "funny and sarcastic"]
```

---

**Social Proof Post Creator** — Turns customer testimonials into social media content
```
Turn this customer testimonial into 3 different social media posts:

Original testimonial: "[PASTE THE TESTIMONIAL HERE]"

Post 1: Instagram carousel intro slide (big, punchy quote format — pull out the most powerful phrase)
Post 2: LinkedIn post (set up the context, share the testimonial, add a 2-sentence reflection from me)
Post 3: Twitter/X (the testimonial condensed into a tweet under 240 characters — add my handle at the end)

My product/service: [BRIEF DESCRIPTION]
Don't add fake details or embellish — use only what's in the original testimonial.
```

---

## Product Listing Optimization

**Etsy Listing Optimizer** — Rewrites your Etsy listing for maximum search visibility and conversions
```
Optimize my Etsy listing for better search rankings and more sales.

My target buyer: [DESCRIBE WHO WOULD BUY THIS]
My top 3 keywords: [LIST THEM]
Current listing title: [PASTE HERE]
Current description: [PASTE HERE]

Rewrite and deliver:
1. OPTIMIZED TITLE (use all 140 characters, front-load the main keyword)
2. OPTIMIZED DESCRIPTION (first 160 characters must be strongest — that's what shows in search. Include all keywords naturally. Add a clear call to action.)
3. TAG SUGGESTIONS (list 13 tags — use the full 20-character limit per tag when possible)
4. THUMBNAIL ALT TEXT (describe the ideal image for this listing + SEO alt text)
5. PRICING NOTE: Is my price competitive for this type of item? (I'll tell you my price: [YOUR PRICE])
```

---

**Amazon Product Listing Rewrite** — Optimizes your Amazon title, bullets, and description
```
Rewrite my Amazon product listing to rank higher and convert better.

Product: [BRIEF DESCRIPTION OF YOUR PRODUCT]
My main keyword: [KEYWORD]
Secondary keywords: [2–3 MORE KEYWORDS]
Target customer: [WHO BUYS THIS]

Rewrite:
1. TITLE (under 200 characters — main keyword first, key benefits, brand name last)
2. BULLET POINTS (write 5 bullets — each starts with a capitalized benefit phrase, followed by a brief explanation. Focus on benefits over features.)
3. PRODUCT DESCRIPTION (3–4 short paragraphs — story-driven, addresses objections, ends with CTA)
4. BACKEND KEYWORD SUGGESTIONS (list 10 additional keywords for the backend fields — things that aren't in the title or bullets)

Current listing:
Title: [PASTE]
Bullets: [PASTE]
Description: [PASTE]
```

---

**Gumroad Product Page Optimizer** — Maximizes your Gumroad conversion rate
```
Optimize my Gumroad product page for more conversions. Here's what I currently have:

Product name: [YOUR PRODUCT NAME]
Current description: [PASTE YOUR DESCRIPTION]
Price: [YOUR PRICE]
Target buyer: [WHO IS THIS FOR]

Rewrite:
1. PRODUCT NAME (clear, benefit-driven, keyword-rich — under 60 characters)
2. DESCRIPTION (structured as: hook → problem → solution → what's inside → who it's for → social proof → FAQ or objection handling → CTA)
3. HEADLINE for the top of the page (different from the product name — this is the first big line buyers see)
4. 5 BULLET POINTS for "What you'll get" (benefit-first, specific, no vague fluff)
5. CALL TO ACTION TEXT for the buy button (alternatives to the default "I want this!")
```

---

## Real Estate

*These prompts are designed for buyers in the Zero-Down Code program and real estate investors who want to use AI to find and analyze deals.*

**Off-Market Deal Finder Outreach** — Writes personalized letters to motivated sellers
```
Write a direct mail letter to a homeowner who may be motivated to sell their property. This is an off-market outreach letter — NOT a spam letter. It must feel personal, empathetic, and low-pressure.

Details:
- Property address or neighborhood: [ADDRESS OR AREA]
- Reason they might be motivated: [e.g., "probate property," "code violations on record," "long-term vacancy," "tax delinquent"]
- My name and company: [YOUR NAME / COMPANY]
- My phone and email: [CONTACT INFO]

Requirements:
- Acknowledge that selling is a big decision
- Show that I'm a real person, not a hedge fund
- Give them a reason to call (fast close, cash, no repairs needed, flexible timeline)
- Keep it under 250 words — one page
- End with a soft, non-pushy CTA
```

---

**Deal Analyzer Prompt** — Evaluates whether a property deal makes financial sense
```
Help me analyze this real estate deal to see if it makes financial sense.

Property details:
- Address: [ADDRESS]
- Purchase price: [PRICE]
- Estimated repairs: [REPAIR COST]
- After Repair Value (ARV): [ESTIMATED VALUE AFTER FIXING UP]
- Your exit strategy: [FLIP / BUY AND HOLD / WHOLESALE]

If FLIP:
- Calculate my estimated profit using the 70% rule (Max offer = ARV × 0.70 − repairs)
- Is my purchase price at or below the 70% rule max offer?
- What profit margin would I make if sold at ARV?

If BUY AND HOLD:
- Estimated monthly rent: [RENT]
- Estimated monthly expenses (mortgage, taxes, insurance, property management, vacancy): [EXPENSES]
- Calculate monthly cash flow
- Calculate cap rate (Net Operating Income ÷ Purchase Price)
- Does this meet the 1% rule? (Monthly rent ≥ 1% of purchase price)

Give me a plain-English verdict: Strong deal / Borderline deal / Walk away — and explain why.
```

---

**Rental Property Listing Writer** — Creates compelling rental listings to fill vacancies fast
```
Write a rental listing for this property that will attract high-quality tenants and fill the vacancy fast.

Property details:
- Location: [CITY, NEIGHBORHOOD]
- Bedrooms / Bathrooms: [e.g., "3BR / 2BA"]
- Rent: [$X/month]
- Key features: [LIST 5–8 FEATURES — e.g., "updated kitchen, hardwood floors, washer/dryer hookups, private backyard, garage"]
- Pet policy: [Yes/No/Dogs only/etc.]
- Available date: [DATE]

Write:
1. HEADLINE (attention-grabbing, leads with the best feature)
2. FULL LISTING DESCRIPTION (250–350 words — organized, specific, no generic filler like "spacious" or "charming")
3. BULLETED FEATURES LIST (10 bullets — the quick-scan version)
4. CALL TO ACTION (how to schedule a showing)

Tone: professional but warm — make this feel like a home, not a transaction.
```

---

## Directory Sites

*These prompts are for solopreneurs building niche directory websites as a business model.*

**Directory Niche Validator** — Evaluates whether a directory niche is worth building
```
I'm thinking about building a niche directory website around [YOUR NICHE IDEA — e.g., "gluten-free restaurants in major US cities" or "remote-friendly coworking spaces worldwide"].

Evaluate this niche for viability by answering:
1. Is there clear search demand? What keywords would people use to find this directory?
2. Who are the top 2–3 existing directories in this niche? How could mine be better?
3. What monetization models make sense? (paid listings / ads / affiliate / lead gen / premium features)
4. How hard would it be to get the first 50 listings? (Do businesses in this niche want to be listed?)
5. What's a realistic traffic timeline for a brand-new directory site?
6. Overall verdict: Strong niche / Viable but competitive / Hard pass — and why

Be honest. I'd rather know it's a bad idea now.
```

---

**Directory Listing Description Writer** — Writes consistent, SEO-friendly descriptions for directory entries
```
Write a directory listing description for [BUSINESS NAME], a [TYPE OF BUSINESS] located in [CITY/LOCATION].

The description should:
- Be 100–150 words
- Open with the most important thing to know (what they do, who they serve)
- Include these details naturally: [LIST 3–5 KEY FACTS — e.g., hours, price range, specialties, notable features]
- Include the target keyword "[KEYWORD]" once or twice naturally
- Sound like it was written by a real editor, not auto-generated
- End with what makes this listing notable or worth visiting

Do NOT use: "a premier destination," "state-of-the-art," "your one-stop shop," "second to none," or any other generic filler phrases.
```

---

**Directory Outreach Email to Potential Listings** — Gets businesses to claim or submit their listing
```
Write an outreach email I can send to businesses asking them to claim their free listing on my directory website.

My directory: [DIRECTORY NAME AND URL]
What the directory covers: [NICHE — e.g., "wedding photographers in Texas"]
Why businesses should be listed: [MAIN BENEFIT — e.g., "We rank on Page 1 for X terms, driving Y visitors/month"]
Free vs. paid: [Is the basic listing free? What does paid upgrade include?]

The email should:
- Be short (under 200 words)
- Open with a specific reference to their business (use [BUSINESS NAME] as a placeholder)
- Lead with the benefit for them, not a sales pitch for me
- Make the next step dead simple (click a link, reply to this email, etc.)
- Not feel like a mass blast — personal and professional

Subject line options: give me 3.
```

---

*This prompt library is a living resource. As the AI landscape evolves, new prompts will be added in future updates. Check ScottHunt.com for the latest version.*

---

*Part of The Autonomous Business Loop — by Scott Hunt*
